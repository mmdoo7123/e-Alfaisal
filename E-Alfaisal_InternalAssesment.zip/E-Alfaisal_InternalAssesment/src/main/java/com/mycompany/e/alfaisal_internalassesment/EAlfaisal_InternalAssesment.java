package com.mycompany.e.alfaisal_internalassesment;

import UserInterface.LogInUI;
import UserInterface.MainMenuUI;
import UserInterface.Meetings.MeetingsUI;

public class EAlfaisal_InternalAssesment {

    public static void main(String[] args) {
        LogInUI mainUI = new LogInUI() ;
        MainMenuUI mainMenu = new MainMenuUI() ; 
        MeetingsUI meetingsUI = new MeetingsUI() ;
       
    } 
}
