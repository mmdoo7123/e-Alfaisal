package media;

public class Icon {
// Create a new JLabel with an ImageIcon

}
