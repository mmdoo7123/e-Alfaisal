package UserInterface.Notes;

class NotesList {

      public static int size() {
        return NotesList.size();
    }

    static void remove(int index) {
            Controllers.Dialogues.showMessage("Error occured");
        }

    static String getItem(int index) {
            Controllers.Dialogues.showMessage("Error occured");
          return null;
    }
}
