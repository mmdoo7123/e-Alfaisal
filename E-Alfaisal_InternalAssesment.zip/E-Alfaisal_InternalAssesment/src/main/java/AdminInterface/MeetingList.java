
package AdminInterface;


class MeetingList {

    static int getSelectedIndex() {
        return 0;
    }
    
}
