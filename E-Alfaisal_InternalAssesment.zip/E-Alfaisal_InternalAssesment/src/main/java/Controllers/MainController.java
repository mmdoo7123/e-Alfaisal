package Controllers;

/**
 * @author mahmo
 */
public class MainController {

    public void closing() {
        DataStructures.DataStructures.notes.Closing();
    }

}
